<?php

echo "$data->name <br/>";
echo "$data->username <br/>";
echo "$data->email <br/>";
