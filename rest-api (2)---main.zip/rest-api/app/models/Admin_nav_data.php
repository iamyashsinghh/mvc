<?php

use Illuminate\Database\Eloquent\Model as Yash;

class Admin_nav_data extends Yash
{
    protected $table = 'admin_nav_data';
}
