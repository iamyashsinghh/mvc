<?php

use Illuminate\Database\Eloquent\Model as Yash;

class Settings extends Yash
{
    protected $table = 'settings';
}
